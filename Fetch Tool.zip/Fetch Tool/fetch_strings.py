﻿"""
Fetch:
A POU, file retreival tool for batch reviewing and reporting of
AMTS One-Off Repair documentation.


@author: David Millsap
         david.millsap@utas.utc.com
         davemillsap@gmail.com

fetch_strings.py:

THIS FILE SERVES HOLDS ALL TEXT DATA FOR THE FETCH MENUS
"""

"""    TEXT FOR TKINTER MENUS    """

aboutText = str('''
Fetch: A POU, file retrieval tool for batch reviewing and
reporting of AMTS One-Off Repair documentation and
E-mail correspondence.

Written By: David Millsap
Email: david.millsap@utas.utc.com

Copyright 2017


Artwork: Kevin Strinz


Fetch is written in Python 3.
Version: 1.7
Icon File used in accordance with GNU LGPL.
''')

readMeText = str('''
How to play Fetch:

1) Type or paste log numbers into the text field, one log per line.

2) Select which One-Off Documents you would like to retreive.

3) Select the file types of the requested documents.

4) Choose one of the following "Fetch" requests:

OPEN FILES: Opens all requested documents in all selected formats in each
log number.

OPEN STRESS/REPAIR FOLDER: Opens each log number's Stress or Repair folder

COPY FILES: Copies all requested documents in all selected formats in each
log number to the "Fetch Downloads" folder on the user's desktop.

READ EMAILS: Extracts the text from Outlook email files contained in
each log, sorted by name, and displays it in a text file. User can

PDF SLICER: Compiles PDF pages from multiple documents into one document and
downloads the file to the "Fetch Downloads" folder on the user's desktop.

***WARNING***: When opening Microsoft Word, Excel or Outlook files, it is
better to have these applications already running before sending the fetch
request.

***WARNING***: Fetch does not limit the amount of documents you can open.
So keep that in mind if you try to open 15 Excel documents at once and your
computer runs out of ram and freezes.

''')

emailMenuText = '''
Emails are sorted by filename.Enter digits (e.g. 1,2,5,7) for specific emails or use dynamic queries "ALL" or "FL" for all emails or just the first and last email in each folder. 
'''

pdfSlicerMenuText = '''
Slices specific pages out of multiple PDF documents and compiles into a single PDF. The slicing index is exclusive. For example, entry "2,5" slices pages 2 through 4. Entry "n,n" slices the first "n" pages of the pdf. So, "2,2" slices the first two pages.'''

