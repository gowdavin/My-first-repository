﻿"""
AMTS_DB.py:  
THIS MODULE CONTAINS QUERY CLASSES FOR AFTERMARKET TECHNICAL SERVICES DATABASES
---
@author: David Millsap
         david.millsap@utas.utc.com
         G0069102
"""
import os
import PyPDF2
import datetime
import shutil
import re
import getpass
import logging
import win32com.client
import glob
import tempfile
import requests
from requests_ntlm import HttpNtlmAuth
import getpass

from tkinter import messagebox

siteURL = 'https://c-lite.utas.utc.com/sites/AMTSCRM'


class FetchCSLog(object):
    """
    The FetchCSLog class takes a list of log numbers and a list of keywords for initialization.
    Database Methods: openPath, openFiles, copyFiles, pdfSlicer, and fetchEmails.   
    """

    path = r'//Netapp3/Cust Repairs/Database/'
 

    def __init__(self, logList, keyWords):
        '''Class Constructor'''
        self.logList = logList
        self.keyWords = keyWords


    def openPath(self, folder):
        """
        Given a folder name as a string, opens all paths for self.logList
        """
        badPaths = []
        for log in self.logList:
            getPath = getLogFolderPath(self.path, log, folder)
            try:
                os.startfile(getPath)
            except FileNotFoundError:
                badPaths.append(log)
                pass
        if len(badPaths) > 0:
               messagebox.showerror('Invalid Logs', '\n'.join(badPaths))
        return


    def openFiles(self, fileTypes):
        """
        Given a list of filetypes, opens all files for self.loglist and
        self.keyWords
        """
        revLogRegEx = re.compile(r'[C][V]\d\d-\d{4,5}\sREV\s\D', flags=re.I)
        files = []
        badPaths = []
        for log in self.logList:
            getPath = getLogFolderPath(self.path, log, 'Stress')
            if revLogRegEx.match(log):  # This accounts for REV A file in REV B log
                rootLog = log[:-6]
            else:
                rootLog = log
            try:
                for filename in os.listdir(getPath):
                    for key in self.keyWords:
                        if (
                            filename.endswith(tuple(fileTypes)) and
                            key.lower() in filename.lower() and
                            rootLog.lower() in filename.lower()
                           ):
                            files.append(os.path.join(getPath, filename))

            except FileNotFoundError:
                userID = getpass.getuser()
                logging.warning('Invalid Log Number: {}  {}'.format(log, userID))
                badPaths.append(log)
                pass

        if len(badPaths) > 0:
            messagebox.showerror('Invalid Logs', '\n'.join(badPaths))

        uniqueFiles = list(set(files)) # removes any duplicate file names
        files_in_use = []

        for file in uniqueFiles:
            if file.endswith('.pdf'):
                os.startfile(file)
                continue
            try:
                os.rename(file, file)  # Checks if non-PDF file is in use or not
            except PermissionError:
                files_in_use.append(os.path.split(file)[1])
                pass
            else:
                os.startfile(file)

        if len(uniqueFiles) == 0:
            messagebox.showinfo('!!!', 'No Results Found')
        if len(files_in_use) > 0:
            messagebox.showerror('Files In Use', '\n'.join(files_in_use))
        return 


    def copyFiles(self, fileTypes):
        """
        Given a list of fileTypes, copies all files in self.logList and
        self.Keywords
        """
        revLogRegEx = re.compile(r'[C][V]\d\d-\d{4,5}\sREV\s\D', flags=re.I)
        files = []
        files_in_use = []
        badPaths = []
        for log in self.logList:
            getPath = getLogFolderPath(self.path, log, 'Stress')
            if revLogRegEx.match(log):  # This accounts for REV A file in REV B log
                rootLog = log[:-6]
            else:
                rootLog = log
            try:
                for filename in os.listdir(getPath):
                     for key in self.keyWords:
                        for file in fileTypes:
                            if (
                                filename.endswith(tuple(fileTypes)) and
                                key.lower() in filename.lower() and
                                rootLog.lower() in filename.lower()
                               ):
                                files.append(os.path.join(getPath, filename))

            except FileNotFoundError:
                badPaths.append(log)
                continue
    
        if len(badPaths) > 0:
            messagebox.showerror('Invalid Logs', '\n'.join(badPaths))

        if len(files) > 0:
            destPath = destPathMaker()
            if os.path.isdir(destPath) == False:
                os.makedirs(destPath)
            uniqueFiles = list(set(files))
            for file in uniqueFiles:
                if file.endswith('.pdf'):
                    shutil.copy(file, destPath)
                    continue
                try:
                    os.rename(file, file) # Check if File in Use
                except PermissionError:
                    userID = getpass.getuser()
                    logging.warning('File in Use: {}  {}'.format(log, userID))
                    files_in_use.append(os.path.split(file)[1])
                    continue
                else:
                    shutil.copy(file, destPath)

        

            if len(files_in_use) > 0:
                messagebox.showerror('Files In Use:', '\n'.join(files_in_use))

            messagebox.showinfo('Results','{} files copied to fetch downloads.'.format(str(len(uniqueFiles))))
        else:
            messagebox.showinfo('Results','No Files Copied.')
        return


    def pdfSlicer(self, StartPage, EndPage):
        """
        Given a StartPage and End Page, returns a single PDF with
        the first page  of each retrieved file with self.keyWord in its
        filename for self.logList
        """

        if StartPage == EndPage:
            StartPage = 1
            EndPage = int(EndPage)+1

        revLogRegEx = re.compile(r'[C][V]\d\d-\d{4,5}\sREV\s\D', flags=re.I)
        files = []
        badPaths = []
        for log in self.logList:
            getPath = getLogFolderPath(self.path, log, 'Stress')
            if revLogRegEx.match(log):  # This accounts for REV A file in REV B log
                rootLog = log[:-6]
            else:
                rootLog = log
            try:
                for filename in os.listdir(getPath):
                    for key in self.keyWords:
                        if (
                            filename.endswith('.pdf') and key.lower() in
                            filename.lower() and rootLog.lower() in
                            filename.lower()
                           ):
                            files.append(os.path.join(getPath, filename))

            except FileNotFoundError:
                badPaths.append(log)
                continue

        pdfMerger = PyPDF2.PdfFileMerger(strict=False)
        uniqueFiles = list(set(files))
     
        if len(badPaths) > 0:
            messagebox.showerror('Invalid Logs', '\n'.join(badPaths))

        try:
            for file in uniqueFiles:
                pdfFileObj = open(file, 'rb')
                pdfMerger.append(pdfFileObj, pages=(int(StartPage)-1, int(EndPage)-1, 1))

        except ValueError:
            logging.warning('Inputs Must Be of Type: Integer')
            messagebox.showerror('Error','Inputs Must Be of Type: Integer')
            pass
        except IndexError:
            logging.warning('Index Out of Range in File: {}'.format(os.path.split(file)[1]))
            messagebox.showerror('Error','Index Out of Range in File: {}'.format(os.path.split(file)[1]))
            return
        except TypeError:
            logging.warning('Invalid Entry')
            messagebox.showerror('Error','Invalid Entry')
            pass
        else:
            reportFileName = 'Fetch Report.pdf'
            destPath = destPathMaker()
            os.makedirs(destPath)
            reportFilePath = os.path.join(destPath, reportFileName)
            pdfOutput = open(reportFilePath, 'wb')
            pdfMerger.write(pdfOutput)
            pdfOutput.close()
            messagebox.showinfo('Results','{} files found.\nReport in Fetch Downloads'.format(str(len(uniqueFiles))))
        return


    def fetchEmails(self, EmailSelection):
        """
        Given an EmailSelection parameter, complies all emails into a single temporary
        text file for each log in self.logList.
        """
        emails_parsed = 0
        files_in_use = []
        file_selection = EmailFileTypes(EmailSelection)
        for log in self.logList:
            getpath = getLogFolderPath(self.path, log, 'Repair')
            all_emails = sorted(glob.glob('{}\*.msg'.format(getpath)))#, key=os.path.getmtime) 
            if file_selection == True:
                emails = all_emails
            elif file_selection == False:
                emails = [all_emails[i] for i in (0,-1)]
            else:
                try:
                    emails = [all_emails[i] for i in file_selection]
                except IndexError:
                    messagebox.showerror('Error','Index Out of Range')
                    continue
                except TypeError:
                    messagebox.showerror('Error','Invalid Entry')
                    continue
            handle, fn = tempfile.mkstemp(suffix='.txt')
            with os.fdopen(handle,"w", encoding='utf8', errors='surrogateescape',newline='\n') as f:
                try:
                    for email in emails:
                        try:
                            outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
                            msg = outlook.OpenSharedItem(os.path.abspath(email))
                            email_name = os.path.split(email)[1]
                            f.write('|************************************************************|{}'.format(os.linesep))
                            f.write('|************************************************************|{}'.format(os.linesep))
                            f.write('|  START OF EMAIL MESSAGE: {}{}'.format(email_name[:30], os.linesep))
                            f.write('|************************************************************|{}'.format(os.linesep))
                            f.write('|************************************************************|{}'.format(os.linesep))
                            f.write(os.linesep)
                            f.write('Sender Name: {}{}'.format(msg.SenderName, os.linesep))
                            f.write(os.linesep)
                            f.write('Sender Email Address: {}{}'.format(msg.SenderEmailAddress, os.linesep))
                            f.write(os.linesep)
                            f.write('Date Sent: {}{}'.format(msg.SentOn, os.linesep))
                            f.write(os.linesep)
                            f.write('Email Recipient: {}{}'.format(msg.To, os.linesep))
                            f.write(os.linesep)
                            f.write('Email Subject: {}{}'.format(msg.Subject, os.linesep))
                            f.write(os.linesep)
                            count_attachments = msg.Attachments.Count
                            if count_attachments > 0:
                                for item in range(count_attachments):
                                    f.write('File Attachment {}: {}{}'.format(item+1, msg.Attachments.Item(item+1).filename, os.linesep))
                                    f.write(os.linesep)
                            elif count_attachments == 0:
                                f.write('File Attachments: None{}'.format(os.linesep))
                                f.write(os.linesep)
                            f.write('Message Body: {}{}'.format(msg.Body, os.linesep))
                            f.write(os.linesep)
                            f.write('|************************************************************|{}'.format(os.linesep))
                            f.write('|************************************************************|{}'.format(os.linesep))
                            f.write('|  END OF EMAIL MESSAGE: {}{}'.format(email_name, os.linesep))
                            f.write('|************************************************************|{}'.format(os.linesep))
                            f.write('|************************************************************|{}'.format(os.linesep))
                            f.write(os.linesep)
                            f.write(os.linesep)
                            f.write(os.linesep)
                            del outlook, msg
                            emails_parsed += 1
                        except:
                            files_in_use.append(os.path.split(email)[1])
                except Exception as e:
                    logging.error('Error in writing file:', e)

            log_filename = os.path.normpath(os.path.join(os.path.split(fn)[0], '{}_{}'.format(log, os.path.split(fn)[1])))
            os.rename(fn, log_filename)             
            os.startfile(log_filename)

            if len(files_in_use) > 0:
                messagebox.showerror('Files In Use:', '\n'.join(files_in_use))

        return


class FetchSharePoint(object):
    """
    The FetchSharePoint class takes a list of log numbers and a list of keywords for
    initialization.

    Database Methods: openPath, openFiles, copyFiles, and pdfSlicer. 
    """
    path = r'\\c-lite.utas.utc.com@SSL\DavWWWRoot\sites\AMTSCRM\Case'

    def __init__(self, logList, keyWords):
        """Class Constructor"""
        self.logList = logList
        self.keyWords = keyWords

    def openPath(self):
        """Given a list of logNos,and a string keyWord, returns a single PDF with
        the first page  of each retrieved file with keyWord in its filename"""
        for log in self.logList:
            getPath = getSharePointPath(self.path, log)
            os.startfile(getPath)
        return root.config(cursor="")


    def openFiles(self, fileTypes):
        """Given a list of logNos, and a string keyword, opens all files
        with keyword in filename"""
        revLogRegEx = re.compile(r'[C][V]\d\d-\d{4,5}\sREV\s\D', flags=re.I)
        files = []
        for log in self.logList:
            getPath = getSharePointPath(self.path, log)
            if revLogRegEx.match(log):  # This accounts for REV A file in REV B log
                rootLog = log[:-6]
            else:
                rootLog = log
            try:
                for filename in os.listdir(getPath):
                    for key in self.keyWords:
                        if (
                            filename.endswith(tuple(fileTypes)) and
                            key.lower() in filename.lower() and
                            rootLog.lower() in filename.lower()
                           ):
                            files.append(os.path.join(getPath, filename))
            except FileNotFoundError:
                userID = getpass.getuser()
                logging.warning('Invalid Log Number: {}  {}'.format(log, userID))
                pass
        for file in files:
            if file.endswith('.pdf'):
                os.startfile(file)
                continue
            try:
                os.rename(file, file)  # Checks if non-PDF file is in use or not
            except Exception:
                userID = getpass.getuser()
                logging.warning('File in Use: {}  {}'.format(log, userID))
                pass
            else:
                os.startfile(file)
        return root.config(cursor="")


    def copyFiles(self, fileTypes):
        """Given a list of logNos,and a string keyWord, copies all files to
        desktop"""
        revLogRegEx = re.compile(r'[C][V]\d\d-\d{4,5}\sREV\s\D', flags=re.I)
        files = []
        destPath = destPathMaker()
        for log in self.logList:
            getPath = getSharePointPath(self.path, log)
            if revLogRegEx.match(log):  # This accounts for REV A file in REV B log
                rootLog = log[:-6]
            else:
                rootLog = log
            try:
                for filename in os.listdir(getPath):
                    for key in self.keyWords:
                        for file in fileTypes:
                            if (
                                filename.endswith(tuple(fileTypes)) and
                                key.lower() in filename.lower() and
                                rootLog.lower() in filename.lower()
                               ):
                                files.append(os.path.join(getPath, filename))
                            if os.path.isdir(destPath) == False:
                                os.makedirs(destPath)
                            else:
                                continue
            except FileNotFoundError:
                userID = getpass.getuser()
                logging.warning('Invalid Log Number: {}  {}'.format(log, userID))
                continue
        for file in files:
            shutil.copy(file, destPath)
        return root.config(cursor="")


    def pdfSlicer(self, StartPage, EndPage):
        """
        Given a StartPage and End Page, returns a single PDF with
        the first page  of each retrieved file with self.keyWord in its
        filename for self.logList
        """

        if StartPage == EndPage:
            StartPage = 1
            EndPage = int(EndPage)+1

        revLogRegEx = re.compile(r'[C][V]\d\d-\d{4,5}\sREV\s\D', flags=re.I)
        files = []
        badPaths = []
        for log in self.logList:
            getPath = getLogFolderPath(self.path, log, 'Stress')
            if revLogRegEx.match(log):  # This accounts for REV A file in REV B log
                rootLog = log[:-6]
            else:
                rootLog = log
            try:
                for filename in os.listdir(getPath):
                    for key in self.keyWords:
                        if (
                            filename.endswith('.pdf') and key.lower() in
                            filename.lower() and rootLog.lower() in
                            filename.lower()
                           ):
                            files.append(os.path.join(getPath, filename))

            except FileNotFoundError:
                badPaths.append(log)
                continue

        pdfMerger = PyPDF2.PdfFileMerger(strict=False)
        uniqueFiles = list(set(files))
     
        if len(badPaths) > 0:
            messagebox.showerror('Invalid Logs', '\n'.join(badPaths))

        try:
            for file in uniqueFiles:
                pdfFileObj = open(file, 'rb')
                pdfMerger.append(pdfFileObj, pages=(int(StartPage)-1, int(EndPage)-1, 1))

        except ValueError:
            logging.warning('Inputs Must Be of Type: Integer')
            messagebox.showerror('Error','Inputs Must Be of Type: Integer')
            pass
        except IndexError:
            logging.warning('Index Out of Range in File: {}'.format(os.path.split(file)[1]))
            messagebox.showerror('Error','Index Out of Range in File: {}'.format(os.path.split(file)[1]))
            return
        except TypeError:
            logging.warning('Invalid Entry')
            messagebox.showerror('Error','Invalid Entry')
            pass
        else:
            reportFileName = 'Fetch Report.pdf'
            destPath = destPathMaker()
            os.makedirs(destPath)
            reportFilePath = os.path.join(destPath, reportFileName)
            pdfOutput = open(reportFilePath, 'wb')
            pdfMerger.write(pdfOutput)
            pdfOutput.close()
            messagebox.showinfo('Results','{} files found.\nReport in Fetch Downloads'.format(str(len(uniqueFiles))))
        return


def Mid(string, offset, amount):
    """Replicates Mid String Method in VBA"""
    return string[offset-1:offset+amount-1]


def getLogFolderPath(strBasePath, strNo, strFolder):
    """Creates CSlog folder path given basepath, log number and folder name"""
    fiveDigitLogRegEx = re.compile(
        r'[C][V]\d\d-\d{5}|[C][V]\d\d-\d{5}\sREV\s\D', flags=re.I)
    iYear = int(Mid(strNo, 3, 2))

    if fiveDigitLogRegEx.match(strNo):
        iNumber = int(Mid(strNo, 6, 3))
        strPath = str(iNumber) + "00-" + str(iNumber) + "99"
    else:
        iNumber = int(Mid(strNo, 6, 2))
        if iNumber >= 10:
            strPath = str(iNumber) + "00-" + str(iNumber) + "99"
        elif iNumber == 0:
            strPath = "0000-0099"
        else:
            strPath = "0" + str(iNumber) + "00-0" + str(iNumber) + "99"

    if iYear < 50:
        iYear = 2000 + iYear
    else:
        iYear = 1900 + iYear

    if strFolder == "":
        strPath = os.path.join(str(iYear), strPath, strNo)
    else:
        strPath = os.path.join(str(iYear), strPath, strNo, strFolder)

    logFolderStr = strBasePath + strPath
    LogFolderPath = os.path.normpath(logFolderStr)
    return LogFolderPath


def getSharePointPath(strBasePath, logNo):
    """Creates Sharepoint folder path given log number and base path"""
    SharePointStr = os.path.join(strBasePath, logNo)
    SharePointPath = os.path.normpath(SharePointStr)
    return SharePointPath

#TODO: Raised an exception for Kevin Lynch
#TODO: os.environ["HOME"] can replace line #545, should use os.path.abspath() 
def destPathMaker():
    """Makes destination path w/timestamp on desktop
    pass os.makedirs(destPathMaker()) to make folder"""
    #userDesktop = os.path.join(os.environ["HOME"], 'Desktop')
    userDesktop = os.path.join('C:', os.environ["HOMEPATH"], 'Desktop')
    fetchDownloadsFolderName = 'Fetch Downloads'
    fetchDownloadPath = os.path.join(userDesktop, fetchDownloadsFolderName)

    if not os.path.isdir(fetchDownloadPath):
        os.mkdir(fetchDownloadPath)

    if os.path.isdir(fetchDownloadPath):
        folderName = str(datetime.datetime.now()).split('.')[0]
        destFolder = folderName.replace(":", "_")
        destPath = os.path.join(fetchDownloadPath, destFolder)

    return os.path.normpath(destPath)


def EmailFileTypes(inputString):
    '''Email Text Normalizer'''
    try:
        if inputString.lower().strip() == 'all':
            return True
        else:
            StrLst = inputString.split(",")
            normalized = [int(s.strip())-1 for s in StrLst]
            return  normalized
    except AttributeError:
        print('Invalid Entry Type: {} '.format(inputString))
        pass
    except ValueError:
        print('Invalid Entry')
        pass


def FilterRevisions(fileList, revRequest):
    '''Returns a list of files with the requested rev letter'''
    if revRequest == 'all':
        return fileList
    revPattern = '{}{}'.format('rev ', revRequest.lower().strip())
    filtered = [filename for filename in fileList if revPattern in os.path.split(filename.lower())[1]]
    return filtered
        

def sharePointAuthentication(siteURL, userName):
   '''Authenticates with a Sharepoint site using Ntlm
      Called during GUI initialization to improve initialf
      fetch request to Sharepoint Paths
   '''
   try:
       response = requests.get(siteURL, auth=HttpNtlmAuth(userName, getpass.getpass()))
   except requests.exceptions.Timeout:
       pass
   except requests.exceptions.HTTPError as err:
       print (err)
   except requests.exceptions.RequestException as e:
       # Catastrophic Error. Abort!!
       print (e)
       sys.exit(1)
