# -*- coding: utf-8 -*-
"""
Created on Wed Nov  8 22:21:24 2017

@author: David Millsap
         david.millsap@utas.utc.com
         davemillsap@gmail.com

main.py:
        THIS MODULE CONTAINS FETCH GUI AND CALL BACK FUNCTIONS
"""
import os
import sys
import PyPDF2
import datetime
import shutil
import re
import getpass
import logging
import threading


from tkinter import Toplevel, Tk, Message, Label, PhotoImage, Button, Menu, Entry,\
                    Frame, StringVar, Checkbutton, E, W, N, S, END, Text, ttk, CENTER,\
                    BOTTOM


from fetch_strings import aboutText, readMeText, emailMenuText, pdfSlicerMenuText
import AMTS_DB
"""     GLOBAL VARIABLES     """


fetchHome = r'//Netapp3/Cust Repairs/OtherThanDatabase/fetch/fetchData'
fetchVersion = "1.7"

"""    TKINTER GUI VARIABLES   """

memory = ""


LARGE_FONT = ("Verdana", 13)
NORM_FONT = ("Verdana", 12)
SMALL_FONT = ("Verdana", 8)



"""    LOGGING SETUP     """
try:
    logFile = os.path.normpath(os.path.join(fetchHome, 'errorLog.log'))
    logging.basicConfig(filename=logFile, level=logging.ERROR,
                        format='%(asctime)s:%(levelname)s:%(message)s',
                        datefmt='%H:%M:%S')
    logging.captureWarnings(False)
except PermissionError:
    userID = getpass.getuser()
    logging.error('{} Could Not Access Log File'.format(userID))
    pass


def writeUserRecord():
    """ Logs user name, version, and time to logfile"""
    global fetchHome
    global fetchVersion
    filename = 'users.log'
    logFile = os.path.normpath(os.path.join(fetchHome, filename))
    timeStamp = str(datetime.datetime.now()).split('.')[0]
    userID = getpass.getuser()
    try:
        with open(logFile, "a") as outfile:
            outfile.write('{}  {}  {}'.format(userID, timeStamp, fetchVersion))
            outfile.write('\n')
    except IOError:       
        logging.warning('Error Accessing Log File: {}'.format(userID))
        #messagebox.showerror('Connection Error','Cannot connect to Cust Repairs')
        pass #sys.exit()   
""" TKINTER SUBROUTINES   """
 
     
def getKeyWords():
    keyWords = [strRepairCB.get(), strStressCB.get(),
                strRasCB.get(), strTasCB.get(), strTDCB.get()]
    strRepair = "Repair"
    strStress = "STRESS"
    strRAS = "RAS"
    if strRepair in keyWords:
        keyWords.append("OTC")  # Get Shorts Repairs too
    if strStress in keyWords:
        keyWords.append("substantiation")  # Get Shorts Stress too
    if strRAS in keyWords:
        keyWords.append("8110-3")  # Get 8110s too
    while "" in keyWords:
        keyWords.remove("")
    return keyWords


def getFileTypes():
    fileTypes = [strPDFCB.get(), strExcelCB.get(),
                 strWordCB.get(), strMathCadCB.get()]
    strExcel = ".xlsx"
    strDoc = ".docx"
    if strExcel in fileTypes:
        fileTypes.extend([".xls", ".xlsm"])
    if strDoc in fileTypes:
        fileTypes.append(".doc")
    while "" in fileTypes:
        fileTypes.remove("")
    return fileTypes


def clearText():
    """clears text from tkinter widget"""
    text1.delete("1.0", END)


def storeInput():
    """Stores text entry into memory"""
    global memory
    if len(text1.get(1.0, END)[:-1]) == 0:
        return
    else:
        memory = text1.get(1.0, END)[:-1]
        clearText()


def recallInput():
    """ Writes memory to tkinter text widget"""
    global memory
    clearText()
    text1.insert(1.0, memory)


def inputToList(StrVal):
    """Given a comma separated, or newline separated string file returns
    a list of strings matching RegEx object"""
    logRegEx = re.compile(
        r'[C][V]\d\d-\d{4,5}|[C][V]\d\d-\d{4,5}\sREV\s\D', flags=re.I)
    StrLst = StrVal.splitlines()
    cleanLogList = [s.strip() for s in StrLst if logRegEx.match(s)]
    return cleanLogList

""" TKINTER CALL BACKS   """


def openRepairFolder():
    if len(text1.get(1.0, END)[:-1]) == 0:
        return
    else:
        root.config(cursor="wait")
        logList = inputToList(text1.get(1.0, END)[:-1])
        folder = 'Repair'
        keyWords = []
        getFetch = AMTS_DB.FetchCSLog(logList, keyWords)
        getFetch.openPath(folder)
        return root.config(cursor="")


def openStressFolder():
    if len(text1.get(1.0, END)[:-1]) == 0:
        return
    else:
        root.config(cursor="wait")
        logList = inputToList(text1.get(1.0, END)[:-1])
        folder = 'Stress'
        keyWords = []
        getFetch = AMTS_DB.FetchCSLog(logList, keyWords)
        getFetch.openPath(folder)
        return root.config(cursor="")


# THREAD THIS
def openFilesHandler():
    if len(text1.get(1.0, END)[:-1]) == 0:
        return
    elif getKeyWords() == []:
        return
    else:
        root.config(cursor="wait")
        logList = inputToList(text1.get(1.0, END)[:-1])
        keyWords = getKeyWords()
        fileTypes = getFileTypes()
        getFetch = AMTS_DB.FetchCSLog(logList, keyWords)
        getFetch.openFiles(fileTypes)
        return root.config(cursor="")

# THREAD THIS

def copyFilesHandler():
    if len(text1.get(1.0, END)[:-1]) == 0:
        return
    elif getKeyWords() == []:
        return
    else:
        root.config(cursor="wait")
        logList = inputToList(text1.get(1.0, END)[:-1])
        keyWords = getKeyWords()
        fileTypes = getFileTypes()
        getFetch = AMTS_DB.FetchCSLog(logList, keyWords)
        getFetch.copyFiles(fileTypes)
        return root.config(cursor="")

# THREAD THIS

def getPDFPagesHandler():
    if len(text1.get(1.0, END)[:-1]) == 0:
        return
    elif strStartPage.get() == '':
        return
    elif strEndPage.get() == '':
        return
    else:
        root.config(cursor="wait")
        logList = inputToList(text1.get(1.0, END)[:-1])
        keyWords = getKeyWords()
        getFetch = AMTS_DB.FetchCSLog(logList, keyWords)
        getFetch.pdfSlicer(strStartPage.get(), strEndPage.get())
        return root.config(cursor="")

# THREAD THIS


def fetchEmailsHandler():
    if len(text1.get(1.0, END)[:-1]) == 0:
        return
    elif strEmailSelection.get() == '':
        return
    else:
        root.config(cursor="wait")
        logList = inputToList(text1.get(1.0, END)[:-1])
        keyWords = []
        getFetch = AMTS_DB.FetchCSLog(logList, keyWords)
        getFetch.fetchEmails(strEmailSelection.get())
        return root.config(cursor="")


''' TKINTER POPUP MESSAGE FUNCTIONS '''


def popupMessage(title, string):
    popup = Toplevel(root)
    x = root.winfo_rootx()
    y = root.winfo_rooty()
    height = root.winfo_height()
    width = root.winfo_width()
    geom = "200x100+%d+%d" % (x,y)
    popup.geometry(geom)
    popup.wm_title(str(title))
    popup.resizable(False, False)
    label = ttk.Label(popup, font=SMALL_FONT)
    label.config(text=string)
    label.pack()
    B1 = ttk.Button(
        popup, text="Okay", command=popup.destroy)
    B1.pack(side=BOTTOM)
    return


def popupAbout():
    global aboutText
    popupAbout = Toplevel(root)
    x = root.winfo_rootx()
    y = root.winfo_rooty()
    height = root.winfo_height()
    width = root.winfo_width()
    geom = "+%d+%d" % (x + width,y)
    popupAbout.geometry(geom)
    popupAbout.wm_title("About...")
    popupAbout.resizable(False, False)
    labelAbout = Message(popupAbout, text=aboutText)
    labelAbout.grid(row=0, column=0)
    img = PhotoImage(file='snake-wagon-03.gif')
    labelPic = Label(popupAbout, image=img)
    labelPic.image = img
    labelPic.grid(row=1, column=0)
    B1 = ttk.Button(
        popupAbout, text="Okay", command=popupAbout.destroy)
    B1.grid(row=2, column=0)
    return


def popupReadMe():
    global readMeText
    popupReadMe = Toplevel(root)
    x = root.winfo_rootx()
    y = root.winfo_rooty()
    height = root.winfo_height()
    width = root.winfo_width()
    geom = "+%d+%d" % (x+ width,y)
    popupReadMe.geometry(geom)
    popupReadMe.wm_title("fetch readme")
    popupReadMe.resizable(False, False)
    labelReadMe = Message(popupReadMe, text=readMeText)
    labelReadMe.grid(row=0, column=0)
    B1 = ttk.Button(
        popupReadMe, text="Okay", command=popupReadMe.destroy)
    B1.grid(row=1, column=0)
    return


def popupGetPDFPages():
    popupGetPDFPages = Toplevel(root)
    x = root.winfo_rootx()
    y = root.winfo_rooty()
    width = root.winfo_width()
    height = root.winfo_height()
    geom = "+%d+%d" % (x + width,y)
    popupGetPDFPages.geometry(geom)
    popupGetPDFPages.wm_title("PDF Slicer")
    popupGetPDFPages.resizable(False, False)
    label_help = Message(popupGetPDFPages, text=pdfSlicerMenuText, width=400, font=SMALL_FONT) 
    label_startpage = Message(popupGetPDFPages, text='Start Page:')
    label_endpage = Message(popupGetPDFPages, text='End Page:')
    entry_startpage = Entry(popupGetPDFPages, width= 7, font=NORM_FONT, textvariable=strStartPage)
    entry_endpage = Entry(popupGetPDFPages, width=7, font=NORM_FONT, textvariable=strEndPage)
    B1 = ttk.Button(
        popupGetPDFPages, text="Fetch", command=getPDFPagesHandler)
    B2 = ttk.Button(
        popupGetPDFPages, text="Exit", command=popupGetPDFPages.destroy)
    label_help.grid(row=0, column=0, columnspan=2, sticky=W+E)
    label_startpage.grid(row=1, column=0)
    label_endpage.grid(row=2, column=0)
    entry_startpage.grid(row=1, column=1)
    entry_endpage.grid(row=2, column=1)
    B1.grid(row=3, column=0, sticky=W+E, padx=5, pady=5)
    B2.grid(row=3, column=1, sticky=W+E, padx=5, pady=5)
    return


def popupFetchEmails():
    popupFetchEmails = Toplevel(root)
    x = root.winfo_rootx()
    y = root.winfo_rooty()
    height = root.winfo_height()
    width = root.winfo_width()
    geom = "+%d+%d" % (x + width,y)
    popupFetchEmails.geometry(geom)
    popupFetchEmails.wm_title("Fetch Emails")
    popupFetchEmails.resizable(False, False)
    label_help = Message(popupFetchEmails, text=emailMenuText, width=400, font=SMALL_FONT)
    label_email_select = Message(popupFetchEmails, text='Selection:', width=90)
    entry_email_select = ttk.Entry(popupFetchEmails, width= 10, font=NORM_FONT, textvariable=strEmailSelection)
    B1 = ttk.Button(
        popupFetchEmails, text="Fetch", command=fetchEmailsHandler)
    B2 = ttk.Button(
        popupFetchEmails, text="Exit", command=popupFetchEmails.destroy)
    label_help.grid(row=0, column=0, columnspan=2, sticky=W+E)
    label_email_select.grid(row=1, column=0)
    entry_email_select.grid(row=1, column=1)
    B1.grid(row=2, column=0, sticky=W+E, padx=5, pady=5)
    B2.grid(row=2, column=1, sticky=W+E, padx=5, pady=5)
    return
''' MAIN GUI CODE '''


""" WINDOW AND MENUS """

root = Tk()
root.title('fetch (CSLog)')
root.iconbitmap(root, 'Everaldo-Crystal-Clear-Action-file-find.ico')
root.resizable(False, False)
menu = Menu(root)
root.config(menu=menu)
filemenu = Menu(menu, tearoff=0)
menu.add_cascade(label="File", menu=filemenu)
filemenu.add_command(label="Fetch Emails", command=popupFetchEmails)
filemenu.add_command(label="PDF Slicer", command=popupGetPDFPages) 
filemenu.add_separator()
filemenu.add_command(label="Exit", command=root.quit)
helpmenu = Menu(menu, tearoff=0)
menu.add_cascade(label="Help", menu=helpmenu)
helpmenu.add_command(label="Readme", command=popupReadMe)
helpmenu.add_command(label="About", command=popupAbout)
content = ttk.Frame(root)

"""  LABELS   """

entryLabel = ttk.Label(
        content, text="CSLog Numbers", relief='groove',
        background='light blue', anchor=CENTER, font=LARGE_FONT)
docLabel = ttk.Label(
        content, text='Documents', relief='groove', anchor=CENTER, background='light blue', font=LARGE_FONT)
fileLabel = ttk.Label(
        content, text='File Types', relief='groove', background='light blue', anchor=CENTER, font=LARGE_FONT)
cmdLabel = ttk.Label(content, text="E.C.C.N: 9E991", relief='groove', anchor=CENTER,
                 background='light blue', width=40, font=SMALL_FONT)
buttonLabel = ttk.Label(
        content, text='Commands', relief='groove', background='light blue',
        anchor=CENTER, font=LARGE_FONT)

""" WIDGETS """

text1 = Text(content, width=16, height=10, font=NORM_FONT)
#progressbar = ttk.Progressbar(content, mode='indeterminate')

""" BUTTONS """

buttonClear = ttk.Button(content, text="Clear",
                     command=clearText)
buttonStore = ttk.Button(content, text="Store",
                     command=storeInput)
buttonRecall = ttk.Button(content, text="Recall",
                      command=recallInput)
buttonOpen = ttk.Button(content, text='Open Files', command=openFilesHandler)
buttonOpenRepairFolder = ttk.Button(content, text='Open Repair Folder', command=openRepairFolder)
buttonOpenStressFolder = ttk.Button(content, text='Open Stress Folder', command=openStressFolder)
buttonCopy = ttk.Button(content, text='Copy Files', command=copyFilesHandler)

""" TKINTER STRING VARS """
strStartPage = StringVar()
strEndPage = StringVar()
strEmailSelection = StringVar()
strRepairCB = StringVar()
strStressCB = StringVar()
strRasCB = StringVar()
strTasCB = StringVar()
strTDCB = StringVar()
strExcelCB = StringVar()
strWordCB = StringVar()
strMathCadCB = StringVar()
strPDFCB = StringVar()

""" CHECK BUTTONS """
repairCB = Checkbutton(
                       content, text="Definition Sheet", variable=strRepairCB,
                       onvalue="Repair", offvalue=""
                       )
stressCB = Checkbutton(
                       content, text="Stress Dossier", variable=strStressCB,
                       onvalue="STRESS", offvalue=""
                       )
rasCB = Checkbutton(
                       content, text="RAS / 8110-3", variable=strRasCB,
                       onvalue="RAS", offvalue=""
                       )
tasCB = Checkbutton(
                       content, text="TAS", variable=strTasCB, onvalue="TAS",
                       offvalue=""
                       )
tdCB = Checkbutton(
                       content, text="Tech Disposition", variable=strTDCB,
                       onvalue="TD", offvalue=""
                       )
pdfCB = Checkbutton(
                       content, text="PDF", variable=strPDFCB, onvalue=".pdf",
                       offvalue=""
                       )
excelCB = Checkbutton(
                       content, text="Excel", variable=strExcelCB,
                       onvalue=".xlsx", offvalue=""
                       )
wordCB = Checkbutton(
                       content, text="Word", variable=strWordCB,
                       onvalue=".docx", offvalue=""
                       )
mathCadCB = Checkbutton(
                       content, text="MathCAD", variable=strMathCadCB,
                       onvalue=".xmcd", offvalue=""
                       )
""" DRAW GUI  """

content.grid(column=0, row=0)
entryLabel.grid(column=0, row=0, sticky=W+E, columnspan=2)
text1.grid(column=0, row=1, sticky=W+E, padx=1, pady=10, rowspan=2)
buttonClear.grid(column=1, row=1, sticky=N+W+E, padx=5, pady=15)
buttonStore.grid(column=1, row=1, sticky=W+E, padx=5, pady=15)
buttonRecall.grid(column=1, row=1, sticky=S+W+E, padx=5, pady=15)
docLabel.grid(column=0, row=3, sticky=W+E)
repairCB.grid(column=0, row=4, sticky=W)
stressCB.grid(column=0, row=5, sticky=W)
rasCB.grid(column=0, row=6, sticky=W)
tasCB.grid(column=0, row=7, sticky=W)
tdCB.grid(column=0, row=8, sticky=W)
fileLabel.grid(column=1, row=3, sticky=W+E)
pdfCB.grid(column=1, row=4, sticky=W)
excelCB.grid(column=1, row=5, sticky=W)
wordCB.grid(column=1, row=6, sticky=W)
mathCadCB.grid(column=1, row=7, sticky=W)
buttonLabel.grid(column=0, row=9,  columnspan=2, sticky=W+E, pady=5)
buttonOpen.grid(column=0, row=10, sticky=W+E, columnspan=2, padx=5, pady=5)
buttonOpenRepairFolder.grid(column=0, row=11, sticky=W+E, columnspan=2, padx=5,
                      pady=5)
buttonOpenStressFolder.grid(column=0, row=12, sticky=W+E, columnspan=2, padx=5,
                      pady=5)
buttonCopy.grid(column=0, row=13, sticky=W+E, columnspan=2, padx=5, pady=5)
#buttonFetchEmails.grid(column=0, row=13, sticky=W+E, columnspan=2, padx=5, pady=5)
cmdLabel.grid(column=0, row=14, sticky=W+E, columnspan=2)
#progressbar.grid(column=0, row=15, sticky=W+E, columnspan=2)
writeUserRecord()
root.mainloop()

